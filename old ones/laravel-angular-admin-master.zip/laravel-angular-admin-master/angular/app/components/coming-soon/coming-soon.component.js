class ComingSoonController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const ComingSoonComponent = {
  templateUrl: './views/app/components/coming-soon/coming-soon.component.html',
  controller: ComingSoonController,
  controllerAs: 'vm',
  bindings: {}
}

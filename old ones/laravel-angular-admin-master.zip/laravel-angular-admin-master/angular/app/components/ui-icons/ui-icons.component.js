class UiIconsController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const UiIconsComponent = {
  templateUrl: './views/app/components/ui-icons/ui-icons.component.html',
  controller: UiIconsController,
  controllerAs: 'vm',
  bindings: {}
}

ngDescribe({
  name: 'Test routeCssClassnames component',
  modules: 'app',
  element: '<route-bodyclass></route-bodyclass>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

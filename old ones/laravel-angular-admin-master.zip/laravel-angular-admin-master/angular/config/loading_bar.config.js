export function LoadingBarConfig (cfpLoadingBarProvider) {
  'ngInject'
  cfpLoadingBarProvider.includeSpinner = true
}

ngDescribe({
  name: 'Test user-verification component',
  modules: 'app',
  element: '<user-verification></user-verification>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

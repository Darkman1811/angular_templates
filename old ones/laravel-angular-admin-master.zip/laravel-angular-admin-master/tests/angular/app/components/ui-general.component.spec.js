ngDescribe({
  name: 'Test ui-general component',
  modules: 'app',
  element: '<ui-general></ui-general>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

ngDescribe({
  name: 'Test charts-chartjs component',
  modules: 'app',
  element: '<charts-chartjs></charts-chartjs>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

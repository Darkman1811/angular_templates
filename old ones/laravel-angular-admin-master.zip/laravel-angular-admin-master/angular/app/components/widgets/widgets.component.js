class WidgetsController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const WidgetsComponent = {
  templateUrl: './views/app/components/widgets/widgets.component.html',
  controller: WidgetsController,
  controllerAs: 'vm',
  bindings: {}
}

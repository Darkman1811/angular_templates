class UiGeneralController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const UiGeneralComponent = {
  templateUrl: './views/app/components/ui-general/ui-general.component.html',
  controller: UiGeneralController,
  controllerAs: 'vm',
  bindings: {}
}

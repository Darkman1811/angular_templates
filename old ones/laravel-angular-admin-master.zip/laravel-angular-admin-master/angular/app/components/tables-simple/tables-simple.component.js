class TablesSimpleController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const TablesSimpleComponent = {
  templateUrl: './views/app/components/tables-simple/tables-simple.component.html',
  controller: TablesSimpleController,
  controllerAs: 'vm',
  bindings: {}
}

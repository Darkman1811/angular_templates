ngDescribe({
  name: 'Test forms-general component',
  modules: 'app',
  element: '<forms-general></forms-general>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

ngDescribe({
  name: 'Test ui-timeline component',
  modules: 'app',
  element: '<ui-timeline></ui-timeline>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

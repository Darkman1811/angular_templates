ngDescribe({
  name: 'Test coming-soon component',
  modules: 'app',
  element: '<coming-soon></coming-soon>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

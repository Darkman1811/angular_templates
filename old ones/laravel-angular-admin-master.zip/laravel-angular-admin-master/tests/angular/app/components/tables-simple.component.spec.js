ngDescribe({
  name: 'Test tables-simple component',
  modules: 'app',
  element: '<tables-simple></tables-simple>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

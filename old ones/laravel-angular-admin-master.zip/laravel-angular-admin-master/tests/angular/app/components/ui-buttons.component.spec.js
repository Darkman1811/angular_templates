ngDescribe({
  name: 'Test ui-buttons component',
  modules: 'app',
  element: '<ui-buttons></ui-buttons>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

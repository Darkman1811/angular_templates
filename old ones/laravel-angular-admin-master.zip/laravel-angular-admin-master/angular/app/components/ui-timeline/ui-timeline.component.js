class UiTimelineController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const UiTimelineComponent = {
  templateUrl: './views/app/components/ui-timeline/ui-timeline.component.html',
  controller: UiTimelineController,
  controllerAs: 'vm',
  bindings: {}
}

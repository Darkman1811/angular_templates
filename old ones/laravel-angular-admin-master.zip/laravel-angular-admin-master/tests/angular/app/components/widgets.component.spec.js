ngDescribe({
  name: 'Test widgets component',
  modules: 'app',
  element: '<widgets></widgets>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

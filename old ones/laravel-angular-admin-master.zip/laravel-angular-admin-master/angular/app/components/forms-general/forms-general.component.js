class FormsGeneralController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const FormsGeneralComponent = {
  templateUrl: './views/app/components/forms-general/forms-general.component.html',
  controller: FormsGeneralController,
  controllerAs: 'vm',
  bindings: {}
}

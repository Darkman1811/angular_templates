class UiButtonsController {
  constructor () {
    'ngInject'

  //
  }

  $onInit () {}
}

export const UiButtonsComponent = {
  templateUrl: './views/app/components/ui-buttons/ui-buttons.component.html',
  controller: UiButtonsController,
  controllerAs: 'vm',
  bindings: {}
}

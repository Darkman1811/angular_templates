ngDescribe({
  name: 'Test ui-modal component',
  modules: 'app',
  element: '<ui-modal></ui-modal>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

ngDescribe({
  name: 'Test ui-icons component',
  modules: 'app',
  element: '<ui-icons></ui-icons>',
  tests: function (deps) {
    it('basic test', () => {
      //
    })
  }
})

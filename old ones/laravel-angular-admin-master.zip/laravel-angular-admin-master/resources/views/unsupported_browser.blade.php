<!doctype html>
<html ng-app="app">
<head>
    <title>Laravel 5 angular material starter</title>
</head>
<body style="background-color: #FBFBFB;text-align:center;font-family: Helvetica, Arial;color: #717887">


<h3 style="margin-top: 200px;font-size:20px;font-weight:bold;">Please update your browser</h3>
<br>
<div style="font-size:16px;line-height: 23px;">You are using an old version of Internet Explorer<br>
    Please update it or try one of these options.
</div>
<br>
<br>

<div style="display: inline-block">
    <a target="_blank" href="https://www.mozilla.org/en-US/firefox/new/" style="text-decoration: none;">
        <img src="https://i.imgur.com/icGtPQC.png"/><br>
    </a>
</div>

<div style="display: inline-block;width:50px;height:1px;"></div>

<div style="display: inline-block">
    <a target="_blank" href="https://www.google.com/chrome/browser/desktop/index.html" style="text-decoration: none;">
        <img src="https://i.imgur.com/2J8FJ1Z.png"/><br>
    </a>
</div>


</body>
</html>
